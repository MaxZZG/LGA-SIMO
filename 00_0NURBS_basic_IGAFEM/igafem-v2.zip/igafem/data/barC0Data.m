knotVec    = [0 0  1 1];
controlPts = [0 0;
	          1 0];
p       = 1;

knotVec = knotVec/max(knotVec);
weights = ones(1,2);

noGPs   = 1;
cd C_files_win
mex NURBSbasis.cpp NURBS.cpp
mex NURBSinterpolation.cpp NURBS.cpp
mex NURBS1DBasisDers.cpp NURBS.cpp
mex NURBS1DBasis2ndDers.cpp NURBS.cpp
mex NURBS2Dders.cpp NURBS.cpp
mex NURBS2DBasisDers.cpp NURBS.cpp
mex NURBS2DBasis2ndDers.cpp NURBS.cpp
mex BSPLINE2DBasisDers.cpp NURBS.cpp
mex NURBS2DBasisDersSpecial.cpp NURBS.cpp
mex NURBSfdfd2fInterpolation.cpp NURBS.cpp
mex NURBS3DBasisDers.cpp NURBS.cpp
mex NURBS3DBasisDersSpecial.cpp NURBS.cpp
cd ..
cd C_files
mex NURBSbasis.c NURBS.c
mex NURBSinterpolation.c NURBS.c
mex NURBS1DBasisDers.c NURBS.c
mex NURBS1DBasis2ndDers.c NURBS.c
mex NURBS2Dders.c NURBS.c
mex NURBS2DBasisDers.c NURBS.c
mex NURBS2DBasis2ndDers.c NURBS.c
mex BSPLINE2DBasisDers.c NURBS.c
mex NURBS2DBasisDersSpecial.c NURBS.c
mex NURBSfdfd2fInterpolation.c NURBS.c
mex NURBS3DBasisDers.c NURBS.c
mex NURBS3DBasisDersSpecial.c NURBS.c
cd ..